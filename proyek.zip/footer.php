<!-- Button Contact Us -->
<div class="text-center my-3">
    <a class="btn btn-lg btn-dark" href="contactus.php" role="button">CONTACT US</a>
</div>
<footer class="footer bg-dark py-5">
    <div class="container">
        <div class="medium text-center text-light">
            Copyright ©2020 - Squee Store
        </div>
        <div class="small text-center text-light">
            SqueeStore creates a clean and comfortable shopping environment and atmosphere as all customers want.<br>
            Cheap, Complete, and Comfortable
        </div>   
    </div>
</footer>