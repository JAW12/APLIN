// tambahan winda

function showModal() {
    $('#myModal').modal('show');
}

function showAlertModal() {
    $('#alertModal').modal('show');
}