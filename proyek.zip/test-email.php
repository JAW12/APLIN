<?php
include __DIR__."system/function-library.php";

sendEmail("jem.angkasa91@gmail.com", "Coba Kirim", "Halo dunia!");